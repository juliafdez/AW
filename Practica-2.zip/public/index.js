"use strict";

let log;
let encriptado;
let cartasAJugar=[];//preguntar si esto se puede hacer

/*
 * Manejador que se ejecuta cuando el DOM se haya cargado.
 */
$(() => {
    $(document).ready(function(){
        
        $("LOGIN").show();
        $("#enca").hide();
        $("#registrar").on("click", nuevoUsu);
        $("#aceptar").on("click", login);
        $("#unirse").on("click", unirse);
        $("#crearP").on("click", addPartidayUser);
        $("#misPartidas").on("click", verMisPartidas);
        $("#todas").on("click","button.botones1", partidaActual);
        $("#actualizar").on("click", actualizar);
        $("#actualizar1").on("click", actualizar);
        $("#volver").on("click", volver);
        $("#volver1").on("click", volver);
        $("#volver2").on("click", volver);
        $("#desconectar").on("click", desconectar);
        $("#imagenes").on("click","img",CartasJugar);
        $("#jugarCartas").on("click", jugar);
        $("#mentiroso").on("click", mentiroso);
    })

});

function nuevoUsu(){
    let usuario =$("#email").val();
    let passw =$("#password").val();
    if(usuario !== "" && passw !== ""){
        $.ajax({
            method: "POST",
            url: "/registro.html",
            contentType: "application/json",
            data: JSON.stringify({nombre:usuario, password: passw}),
            success: function(data, textStatus, jqXHR){
                $("#LOGIN").hide();
                $("#enca").show();
                log = usuario;
                encriptado = btoa(usuario +":" + passw);
                $("#PARTIDAS").show();
                $("#usuario").text(data);
            },
            error: function (jqXHR, textStatus, errorThrown) {
                alert("Se ha producido un error: El usuario ya está registrado (" + errorThrown + ")");
                }
        })
    }else{
        alert("Hay algún campo vacío");
    }
}

function login(){
    let usuario =$("#email").val();
    let passw =$("#password").val();

    
    if(usuario !== "" && passw !== ""){
        $.ajax({
            method: "POST",
            url: "/login.html",
            contentType: "application/json",
            data: JSON.stringify({nombre:usuario, password: passw}),
            success: function(data, textStatus, jqXHR){
                $("#LOGIN").hide();
                $("#enca").show();
                log = usuario;
                console.log(log);
                encriptado = btoa(usuario +":" + passw);
                $("#PARTIDAS").show();
                $("#usuario").text(data);
            },
            error: function (jqXHR, textStatus, errorThrown) {
                console.log(textStatus);
                alert("Se ha producido un error: El usuario y/o contraseña no está registrado (" + errorThrown + ")");
                }
        })
    }else{
        alert("Hay algún campo vacío.");
    }
}

function addPartidayUser(){
    let part =$("#nombrePartida").val();
    if(part !== ""){
        $.ajax({
            method: "POST",
            url: "/nuevaPartida.html",
            contentType: "application/json",
            data: JSON.stringify({nombrePartida:part}),
            beforeSend: function(req) {
                
                // Añadimos la cabecera 'Authorization' con los datos
                // de autenticación.
                req.setRequestHeader("Authorization"
                ,
                "Basic " + encriptado);
                },
            success: function(data, textStatus, jqXHR){
                $("#LOGIN").hide();
                $("#enca").show();
                $("#LISTAPARTIDAS").hide();
                $("#PCREADA").show();
                $("#PARTIDAS").show();
                $("#usuario").text(data.nombre);
            },
            error: function (jqXHR, textStatus, errorThrown) {
                alert("Se ha producido un error: Esta partida ya está creada (" + errorThrown + ")");
                }
        });
    }else{
        alert("No has rellenado el campo de nombre de la partida.");
    }
}

function partidaToDoElement(partida){
    let result = $("<li>").addClass("misPartidas");
    result.append($("<button>").text(partida.nombre).addClass("botones1").data("id", partida.id));
   // result.data("id",partida.id);
    return result;
}

function cartasToDoElement(carta){
    let result = $("<img>").prop("src", "imagenes/"+ carta + ".png");
    result.prop("value", carta);
    $("#imagenes").append(result);
   // result.data("id",partida.id);
}

function verMisPartidas(){
    $.ajax({
        method: "GET",
        url:"/mostrarPartidas.html",
        contentType: "application/json",
       // data: JSON.stringify({partidas:partidas}),
        beforeSend: function(req) {

            // Añadimos la cabecera 'Authorization' con los datos
            // de autenticación.
            req.setRequestHeader("Authorization"
            ,
                "Basic " + encriptado);

            },
        success: function(data, textStatus, jqXHR){
            $("#todas").empty();
            $("#enca").show();
            $("#LISTAPARTIDAS").show();
            $("#PCREADA").hide();
            $("#PARTIDAS").show();
            $("#usuario").text(data.usu);
            data.partidas.forEach(element => {
                let partida=partidaToDoElement(element);
                $("#todas").append(partida);
            });        
        },
        error: function(jqXHR,textStatus,errorThrown){
            alert("Se ha producido un error: No tienes ninguna partida aún ("+ errorThrown + ")");
        }
    });
}

function unirse(){
    let part =$("#idPartida").val();
    //let usu = $("#login").val(); COMO COGEMOS EL ID DEL USUARIO
    if(part !== ""){
        $.ajax({
            method: "POST",
            url: "/unirse.html",
            contentType: "application/json",
            data: JSON.stringify({idPartida:part}),
            beforeSend: function(req) {
                
                // Añadimos la cabecera 'Authorization' con los datos
                // de autenticación.
                req.setRequestHeader("Authorization"
                ,
                "Basic " + encriptado);
                },
            success: function(data, textStatus, jqXHR){
                $("#LOGIN").hide();
                $("#enca").show();
                $("#PARTIDAS").show();
                $("#PCREADA").hide();
                $("#TEHASUNIDO").show();
                $("#LISTAPARTIDAS").hide();
                $("#usuario").text(data.nombre);
            },
            error: function (jqXHR, textStatus, errorThrown) {
                alert("Se ha producido un error: ya estás en esta partida o la partida no existe (" + errorThrown + ")");
                }
        });
    }else{
        alert("No has rellenado el campo del id de la partida.");
    }
}

function getPartida(id){
    $.ajax({
        method: "GET",
        url:"/partida/" + id,
        contentType: "application/json",
      //  data: JSON.stringify({jugadores:jugadores, usu:usu}),
        beforeSend: function(req) {
            req.setRequestHeader("Authorization"
            ,
                "Basic " + encriptado);

            },
        success: function(data, textStatus, jqXHR){
            if(data.estadoP ==="terminada"){
                $("#JUGANDO").hide();
                $("#enca").show();
                $("#PARTIDAS").hide();
                $("#usu").text(data.usu);
                $("#GANADO").show();
                $("#ganador").text(data.nombreGanador);

            }else{
                let h="";
                data.historial.forEach(k=>{
                    h+= k.evento + " " + k.hora + "\n";
                });
                $("#historial").text(h);
                $("#historial").show();
                $("#enca").show();
                $("#PARTIDAS").hide();
                $("#nombreP").text(data.nombrePartida);
                $("#usu").text(data.usu);
                $("#LOGIN").hide();
                if(data.cartasJug === undefined){
                    let i = 1;
                    $("#idPart").data("id", id);
                    data.jugadores.forEach(p=>{
                        ($("#j" + i).text([p.login]));
                        i++;
                    });
                    $("#PARTIDAACTUAL").show();
                    $("#idPart").text(data.idPartida);
                }
               
               else{
                if(data.cartasMesa === 0){
                    $("#numeroAJugar").show();
                }else{
                    $("#numeroAJugar").hide();
                }
                let i = 1;
                data.jugadores.forEach(p=>{
                    ($("#jp" + i).text([p.login]));
                    i++;
                });
                let j = 1;
                data.restoCartas.forEach(p=>{
                    ($("#cp" + j).text([p]));
                    j++;
                });
                if(data.turnoAnterior!==undefined){
                    $("#nombreJugadorActual").text(data.turnoAnterior);
                    $("#numeroDeCartasColocadas").text(data.ultimas);
                    $("#numeroEnJuego").text(data.vCartas);
                    $("#informacionJugada").show();
                }
                $("#PARTIDAACTUAL").hide();
                $("#nombrePart").text(data.nombrePartida);
                $("#personaTurno").text(data.turno);
                $("#JUGANDO").show();
                $("#idPart").text(data.idPartida);
                $("#imagenes").empty();
                $("#cartasEnJuego").empty();
                data.cartasJug.forEach(p=>{
                    cartasToDoElement(p);
                });
                let x = 0;
                 while(x < data.cartasMesa){
                    $("#cartasEnJuego").append($("<span>").text(data.vCartas).addClass("recuadro"));
                    x++;
                }
                
                $("#palo").text(data.vCartas);
                $("#imagenes").show();
               }
               cartasAJugar=[];
            }
           
        },
        error: function(jqXHR,textStatus,errorThrown){
            alert("Se ha producido un error: "+ errorThrown);
        }
    });
}

function partidaActual(event){
    let selected = $(event.target);
    let id = selected.data("id");

    getPartida(id);
}

function CartasJugar(event){
  
    console.log("He llegado");
    let selected=$(event.target);
    selected.addClass("foto");
    let carta = selected.val();
    let pos =  cartasAJugar.lastIndexOf(carta);
    if(pos === -1){
        cartasAJugar.push(carta);
    }else{
        selected.removeClass("foto");
        cartasAJugar.splice(pos, 1);
    }
    console.log(cartasAJugar);
   // return cartasAJugar;
    
}

function jugar(){
    let idPart = Number($("#idPart").text());
    let cartas = cartasAJugar;
    let cartasDeLaMesa = $("#cartasEnJuego").children();
    let valor = 0;
    //let misCartas = $("#imagenes").
    let turno = $("#personaTurno").text();
    if(turno === log){
        if(cartasDeLaMesa.length===0){
            valor = $("#numeroCarta").val();
        }else{valor = $("#palo").text();}
            if(cartas.length !== 0 && valor !== "" && (valor === "AS" || valor === "J" || valor === "Q" || valor === "K" || Number(valor) > 1 || Number(valor) < 11)){
             $.ajax({
                 method: "PUT",
                 url:"/jugar/"+idPart,
                 contentType: "application/JSON",
                 data:JSON.stringify({cartas:cartas,valor:valor}),
                 beforeSend: function(req) {
                
                    // Añadimos la cabecera 'Authorization' con los datos
                    // de autenticación.
                    req.setRequestHeader("Authorization"
                    ,
                    "Basic " + encriptado);
                    },
                 success:function(data,textStatus,jqXHR){
                    
                    getPartida(idPart);
                 },
                 error:function(jqXHR, textStatus, errorThrown){
                     alert("Se ha producido el error: " + errorThrown);
                 }
                 
             })
            }else{
                alert("No has seleccionado ninguna carta o has introducido mal el numero");
            }
         }else{
            alert("No es tu turno");
        }    

    
}

function mentiroso(){
    let idPart = Number($("#idPart").text());
    let turno = $("#personaTurno").text();
    if(turno === log){
    $.ajax({
        method: "PUT",
                 url:"/mentiroso/"+idPart,
                 contentType: "application/JSON",
                 data:JSON.stringify({}),
                 beforeSend: function(req) {
                
                    // Añadimos la cabecera 'Authorization' con los datos
                    // de autenticación.
                    req.setRequestHeader("Authorization"
                    ,
                    "Basic " + encriptado);
                    },
                 success:function(data,textStatus,jqXHR){
                     let cadena = "";
                     data.guardarUltimas.forEach(p=>{
                        cadena+=p + " ";
                     })
                    if(data.booleano){
                        alert("Tu compañero es un mentiroso!, Estas son sus cartas " + cadena);
                    }else{
                        alert("Has perdido! Tu compañero dice la verdad. " + cadena);
                    }
                    getPartida(idPart);
                 },
                 error:function(jqXHR, textStatus, errorThrown){
                    alert("Se ha producido el error: " + errorThrown);
                }
    })
}else{
    alert("No es tu turno");
}
}

function actualizar(){

    let id =$("#idPart").text();
    console.log(id);
    getPartida(id);
}

function volver(){
    $("#PARTIDAACTUAL").hide();
    $("#PARTIDAS").show();
    $("#JUGANDO").hide();
    $("#GANADO").hide();
    $("#historial").hide();
}

function desconectar(){
    encriptado = "";
    log = "";
    $("#email").prop("value", "");
    $("#password").prop("value", "");
    $("#LOGIN").show();
    $("#PARTIDAACTUAL").hide();
    $("#PARTIDAS").hide();
    $("#enca").hide();
    $("#JUGANDO").hide();
}