module.exports={
    mysqlconfig: {
        dbName: "practica2",
        dbHost: "localhost",
        dbUser: "root",
        dbPassword: "",
    },
    port:3000,
    httpsPort:3300
};