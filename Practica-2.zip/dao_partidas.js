"use strict";


/**
 * Proporciona operaciones para la gestión de usuarios
 * en la base de datos.
 */
class DAOPartidas {
    /**
     * Inicializa el DAO de partidas.
     * 
     * @param {Pool} pool Pool de conexiones MySQL. Todas las operaciones
     *                    sobre la BD se realizarán sobre este pool.
     */
    constructor(pool) {
        this.pool = pool;
    }

    addPartida(partida, callback){
        this.pool.getConnection((err, connection)=>{
            if(err) callback(err);
            else{
                connection.query("INSERT INTO partidas (nombre) VALUES (?)", [partida], (error)=>{
                    if(error){ callback(error);}
                    else callback(null);
                });
            }
            connection.release();
        });
    }

    getIdPartida(partida, callback){
        this.pool.getConnection((err, connection)=>{
            if(err) callback(err);
            else{
                connection.query("SELECT id FROM partidas WHERE nombre = ?", [partida], (error, rows)=>{
                    if(!error){
                        if(rows.length > 0){
                            callback(null, rows[0].id);
                        }else callback(error, undefined);
                    }else callback(error);
                })
            }
            connection.release();
        })
    }

    addUserPartida(idPartida, idUser, callback){
        this.pool.getConnection((err, connection)=>{
            if(err) callback(err);
            else{
                connection.query("INSERT INTO juega_en VALUES (?,?)",[idUser, idPartida], (error)=>{
                    if(error) callback(error);
                    else callback(null);
                })
            }
            connection.release();
        });
    }

    getNumeroJugadoresPartida(idPartida, callback){
        this.pool.getConnection((err, connection)=>{
            if(err) callback(err);
            else{
                connection.query("SELECT count(idUsuario) AS users FROM juega_en WHERE idPartida = ?", [idPartida], (error,rows)=>{
                    if(!error){
                        if(rows[0].users < 4 && rows[0].users > 0){
                            callback(null, rows[0].users);
                        }else callback(null, rows[0].users);
                    }else callback(error, false);
                });
            }
            connection.release();
        });
    }

    misPartidas(user, callback){
        this.pool.getConnection((err, connection)=>{
            if(err) callback(err);
            else{
                connection.query("SELECT nombre, id FROM juega_en, partidas WHERE juega_en.idPartida=partidas.id AND juega_en.idUsuario=?", [user],(error, rows)=>{
                    if(!error){
                        if(rows.length>0){
                            let partidas = [];
                            rows.forEach(p=>{
                                partidas.push({nombre: p.nombre, id: p.id});
                            });
                            callback(null, partidas);
                        }else callback(null, undefined);
                    }else{
                        callback(error, undefined);
                    }
                });
            }
            connection.release();
        });
    }

    getJugadoresPartida(idPartida, callback){
        this.pool.getConnection((err, connection)=>{
            if(err) callback(err);
            else{
                connection.query("SELECT login FROM usuarios, juega_en WHERE juega_en.idUsuario = usuarios.id AND juega_en.idPartida = ?", [idPartida], (error, rows)=>{
                    if(!error){
                        if(rows.length>0){
                            let usuariosPartida = [];
                            rows.forEach(p=>{
                                usuariosPartida.push(p);
                            });
                            callback(null, usuariosPartida);
                        }else callback(null, undefined);
                    }else callback(error, undefined);
                });
            }
            connection.release();
        });
    }

    getNombrePartida(id, callback){
        this.pool.getConnection((err, connection)=>{
            if(err){ callback(err);}
            else{
                connection.query("SELECT nombre FROM partidas WHERE id = ?", [id], (error, rows)=>{
                    if(!error){
                        if(rows.length > 0){
                            callback(null, rows[0].nombre);
                        }else callback(null, undefined);
                    }else callback(error,undefined);
                })
            }
            connection.release();
        })
    }

    guardarEstado(estado,idP, callback){
        this.pool.getConnection((err, connection)=>{
            if(err) callback(err);
            else{
                estado = JSON.stringify(estado);
                connection.query("UPDATE partidas SET estado = ? WHERE id = ?", [estado, idP], (error)=>{
                    if(error) callback(error);
                    else callback(null);
                })
            }
            connection.release();
        });
    }
    
    getEstado(idPartida,callback){
        this.pool.getConnection((err,connection)=>{
            if(err) callback(err);
            else{
                connection.query("SELECT estado FROM partidas WHERE id = ?", [idPartida], (error,rows)=>{
                    if(!error){
                        if(rows.length>0){
                            callback(null,rows[0].estado);
                        }else{
                            callback(null,undefined);
                        }
                    }else{
                        callback(error,undefined);
                    }
                })
            }
            connection.release();
        });
    }

    crearHistorial(evento, id, callback){
        this.pool.getConnection((error, connection)=>{
            if(error) callback(error);
            else{
                connection.query("INSERT INTO historial(idPartida, evento) VALUES (?,?)",[id,evento], (error)=>{
                    if(!error){
                        callback(null);
                    }else callback(error);
                });
            }
            connection.release();
        });
    }

    obtenerHistorial(idPart, callback){
        this.pool.getConnection((error, connection)=>{
            if(error)callback(error);
            else{
                connection.query("SELECT * FROM historial WHERE idPartida = ?", [idPart],(err, rows)=>{
                    if(!err){
                        if(rows){
                            let eventos=[];
                            rows.forEach(p=>{
                                eventos.push({evento:p.evento,hora:p.hora});
                            })
                            callback(null, eventos);
                        }else callback(null, undefined);
                    }else{
                        callback(error, undefined);
                    }
                })
            }
        })
    }
}

module.exports = {
    DAOPartidas: DAOPartidas
}