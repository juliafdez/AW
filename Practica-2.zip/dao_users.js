"use strict";


/**
 * Proporciona operaciones para la gestión de usuarios
 * en la base de datos.
 */
class DAOUsers {
    /**
     * Inicializa el DAO de usuarios.
     * 
     * @param {Pool} pool Pool de conexiones MySQL. Todas las operaciones
     *                    sobre la BD se realizarán sobre este pool.
     */
    constructor(pool) {
        this.pool = pool;
    }

    isUserCorrect(user, callback) {
        this.pool.getConnection((err, connection) => {
            if(err){
                callback(err);
            }
            else{
            connection.query("SELECT login, password FROM usuarios WHERE login = ? and password = ?",
            [user.login, user.password],
            (err, rows) => {
                if (err) { callback(err); }

            else if (rows.length === 0) {
                    callback(null, false);
                } else {
                    callback(null, true);
                }
            });
        }
        connection.release();
        });
        
    }

    newUser(user,callback){
        this.pool.getConnection((err,connection)=>{
            if(err){
                callback(err);
            }
            else{
                connection.query("SELECT login FROM usuarios WHERE login = ?", 
                [user.nombre], 
                (error,rows)=>{
                    if (error) { callback(error); }

                   if (rows.length === 0) {
                        connection.query("INSERT INTO usuarios (login,password) VALUES (?,?)", [user.nombre, user.password],
                        (err)=>{
                            if(err){ callback(err);}
                            else callback(null, true);
                        });
                        
                    } else {
                        callback(null,false);
                    }
                });
                connection.release();
            }
        });
    }  

    getIdUser(nombre, callback){
        this.pool.getConnection((err, connection)=>{
            if(err) callback(err);
            else{
                connection.query("SELECT id FROM usuarios WHERE login = ?", [nombre], (error, rows)=>{
                    if(!error){
                        if(rows.length > 0){
                            callback(null, rows[0].id);
                        }else callback(error, undefined);
                    }else callback(error);
                })
            }
            connection.release();
        })
    }
}

module.exports = {
    DAOUsers: DAOUsers
}