
"use strict";
const express = require("express");
const app = express();
const path = require("path");
const config = require("./config");
const bodyParser = require("body-parser");
const daoUsers = require("./dao_users");
const daoPartidas = require("./dao_partidas");
const mysql =require("mysql");
const passport = require("passport");
const passportHTTP = require("passport-http");
const expressvalidator = require("express-validator");
const https = require("https");
const fs = require("fs");
const cartas = [ 
    "2_C", "2_D", "2_H", "2_S", 
    "3_C", "3_D", "3_H", "3_S",
    "4_C", "4_D", "4_H", "4_S", 
    "5_C", "5_D", "5_H", "5_S", 
    "6_C", "6_D", "6_H", "6_S", 
    "7_C", "7_D", "7_H", "7_S", 
    "8_C", "8_D", "8_H", "8_S",
    "9_C", "9_D", "9_H", "9_S", 
    "10_C", "10_D", "10_H", "10_S", 
    "J_C", "J_D", "J_H", "J_S",
    "Q_C", "Q_D", "Q_H", "Q_S",
    "K_C", "K_D", "K_H", "K_S",
    "A_C", "A_D", "A_H", "A_S"
    ];

let clavePrivada = fs.readFileSync("./mi_clave.pem");
let certificado = fs.readFileSync("./certificado_firmado.crt");
    

let pool = mysql.createPool({
    host:config.mysqlconfig.dbHost,
    user:config.mysqlconfig.dbUser,
    password:config.mysqlconfig.dbPassword,
    database:config.mysqlconfig.dbName
});

let daoUser = new daoUsers.DAOUsers(pool);
let daoPartida = new daoPartidas.DAOPartidas(pool);

let miEstrategia =
    new passportHTTP.BasicStrategy(
    { realm: "Pagina protegida" },
    //meter los datos de la sesion en una variable
    function(user, pass, callback) {
        let userSession = {
            login: user,
            password: pass
        }
        daoUser.isUserCorrect(userSession, (err, correct) => {
            if (!err) {
                if (correct) {
                    callback(null, userSession.login);
                } else {
                    callback(null, false);
                }
            }
        });  
    // Comprobar datos de autenticación
    }
);


const ficherosEstaticos =path.join(__dirname, "public");

app.use(express.static(ficherosEstaticos));
app.set("view engine" , "ejs");
app.set("views", path.join(__dirname, "views"));
app.use(bodyParser.urlencoded({ extended:false}));
app.use(passport.initialize());
passport.use(miEstrategia);
app.use(express.static(path.join(__dirname, "public")));
app.use(bodyParser.json());
app.use(expressvalidator({
    customValidators: {
        notEmptyF: p => {
            return p.trim().length > 0;
        }
}}));

let servidor = https.createServer({key: clavePrivada, cert: certificado}, app);

servidor.listen(config.httpsPort, function(err) {
    if (err) {
        console.log("No se ha podido iniciar el servidor.")
        console.log(err);
    } else {
        console.log(`Servidor https escuchando en puerto ${config.httpsPort}.`);
    }
});

/*Registrar nuevo usuario*/
app.post("/registro.html", (request, response)=>{
    request.checkBody("nombre").notEmpty();
    request.checkBody("password").notEmpty();
    let datos = {nombre:request.body.nombre, password:request.body.password}
    request.getValidationResult().then(resultado=>{
        if(resultado.isEmpty()){
            
            daoUser.newUser(datos, (error,exito)=>{
                if(error){ 
                response.status(500);
                response.end();
                }else{
                    if(!exito){
                        response.status(400);
                        response.end();
                    }else{
                        response.status(201).json(request.body.nombre);
                    }
        
                }
            });
        }else response.status(400);
    })
});

/*Login */

app.post("/login.html", (request, response)=>{
    request.checkBody("nombre").notEmpty();
    request.checkBody("password").notEmpty();
    let datos = {login:request.body.nombre, password:request.body.password}
    request.getValidationResult().then(resultado=>{
        if(resultado.isEmpty()){
           
            daoUser.isUserCorrect(datos, (error, exito)=>{
                if(error){
                    response.status(500);
                    response.end();
                }else{
                    if(!exito){
                        response.status(400);
                        response.end();
                    }else{
                        response.status(200).json(request.body.nombre);
                    }
                }
            });
        }
        
    });
    
});

/*Crear una nueva partida y añadir directamente al creador */

app.post("/nuevaPartida.html",passport.authenticate('basic', {session: false}), (request, response)=>{
    request.checkBody("nombrePartida").notEmpty();
    let partida = request.body.nombrePartida;
    let nombre = request.user;
    request.getValidationResult().then(resultado=>{
        if(resultado.isEmpty()){
            daoPartida.addPartida(partida, (err)=>{//Añadimos la partida a la bd
                if(!err){
                    daoPartida.getIdPartida(partida, (err1, datos)=>{//cogemos el id de partida
                        if(!err1){
                            if(datos){
                                daoUser.getIdUser(nombre, (err2, datos2)=>{//cogemos el id de la persona
                                    if(!err2){
                                        if(datos2){
                                            daoPartida.addUserPartida(datos, datos2, (err3)=>{//añadimos el idUser e idPartida a juega_en(bd)
                                                if(!err3){
                                                    guardarHistorial("El jugador " + request.user + " ha creado la partida", datos, err=>{
                                                        response.status(201).json({partida, nombre});
                                                    });
                                                   
                                                }else {response.status(500);
                                                    response.end();
                                                }
                                            });
                                        }
                                    }else {response.status(500);
                                        response.end();
                                    }
                                });
                            }
                        }else {response.status(500);
                            response.end();
                        }
                    });
                }else{ response.status(500);
                    response.end();
                }
            });
        }
        });
});

/*Unirse a una nueva partida introduciendo el id */

app.post("/unirse.html",passport.authenticate('basic', {session: false}), (request, response)=>{
    request.checkBody("idPartida").notEmpty();
    let idPartida = Number(request.body.idPartida);
    let nombre = request.user;
    request.getValidationResult().then(resultado=>{
        if(resultado.isEmpty()){
            daoPartida.getNumeroJugadoresPartida(idPartida, (error, exito)=>{
                if(!error){
                    if(exito < 4){
                        daoUser.getIdUser(nombre, (error, datos)=>{
                            if(!error){
                                if(datos){
                                     daoPartida.addUserPartida(idPartida, datos , (error)=>{
                                            if(error){
                                                response.status(500);
                                                response.end();
                                            }else{
                                                exito++;
                                                daoPartida.getJugadoresPartida(idPartida, (error,jugadores)=>{
                                                    if(!error){
                                                        if(jugadores){
                                                            if(exito === 4){
                                                                let cartasAleat=aleatorio(cartas);
                                                                        //let jugadoresAleat=aleatorio(jugadores);
                                                                let estado= datosEstado(jugadores, cartasAleat);
                                                                daoPartida.guardarEstado(estado, idPartida, (error)=>{
                                                                if(error){
                                                                    response.status(500);
                                                                    response.end();
                                                                }else{
                                                                    guardarHistorial("El jugador " + request.user + " se ha unido a la partida", idPartida, err=>{
                                                                    response.status(200).json(nombre);
                                                                    });
                                                                }
                                                                
                                                                });
                                                                                
                                                            }else{
                                                                guardarHistorial("El jugador " + request.user + " se ha unido a la partida", idPartida, err=>{
                                                                    response.status(200).json({jugadores, nombre, idPartida});
                                                                });
                                                                
                                                            }
                                                        }else{
                                                            response.status(500);
                                                            response.end();
                                                        }
                                                    }else {
                                                        response.status(500);
                                                        response.end();
                                                    }
                                            });
                                            }
                                    });
                                }else {response.status(400);
                                    response.end();
                                }
                            }else {response.status(500);
                                response.end();
                            }
                        });
                    }else{
                        response.status(400);
                        response.end();
                    } 
                }else {response.status(404);
                    response.end();                
                }
            });
        }
        
    });
    
});

/* Mostrar todas las partidas de un usuario */

app.get("/mostrarPartidas.html",passport.authenticate('basic', {session: false}), (request, response)=>{
    let usu = request.user; //coger nombre de usuario de la sesion
    daoUser.getIdUser(usu, (error, datos)=>{
        if(!error){
            if(datos){
                daoPartida.misPartidas(datos, (error1, partidas)=>{
                    if(!error1){
                        if(partidas){
                            response.status(200).json({partidas, usu});
                        }else {response.status(400);
                            response.end();
                        }
                    }response.status(500);
                    response.end();
                });
            }
        }else {response.status(500);
            response.end();
        }
    });
});

app.get("/partida/:id",passport.authenticate('basic', {session: false}),(request, response)=>{
    let idPartida = request.params.id;
    let usu = request.user;
    daoPartida.getJugadoresPartida(idPartida, (error, jugadores)=>{
        if(!error){
            daoPartida.getNombrePartida(idPartida, (error, nombrePartida)=>{
            if(!error){
                daoPartida.obtenerHistorial(idPartida, (error,historial)=>{
                    if(error) {response.status(500);
                        response.end();
                    }
                    else{
                        if(jugadores.length === 4){
                            if(nombrePartida !== undefined){
                                daoPartida.getEstado(idPartida,(error,estado)=>{
                                    if(!error){
                                        if(estado){
                                        
                                        estado=JSON.parse(estado);
                                        let posJSinCart
                                        let estadoP = "";
                                        let turno = estado.jugadores[estado.turno].login;//turno sig.
                                        let pos = obtenerJugador(usu, jugadores);
                                        let cartasJug = [];
                                        let vCartas = estado.valorCartasMesa;
                                        let restoCartas = cartasRestoJugadores(estado);
                                        let cartasMesa = contarCartas(estado.cartasMesa);
                                        let i = 0;
                                        let nombreGanador = undefined;
                                        estado.jugadores.forEach(p=>{
                                            if(p.cartas.length === 0){
                                                if((i + 1)%4 !== estado.turno){
                                                estado.estadoPartida = "terminada";
                                                nombreGanador = estado.jugadores[i].login;
    
                                                }
                                            }
                                            i++;
                                        });
                                        estadoP = estado.estadoPartida;
                                        let ultimas = estado.ultimasCartas.length;
                                        let turnoAnterior = undefined;//nuestro turno 
                                        let posTurnoAnterior;
                                        if(estado.turno === 0){
                                            posTurnoAnterior = 3;
                                        }else{
                                            posTurnoAnterior = (estado.turno -1);
                                        }
                                        if(cartasMesa!==0){
                                            turnoAnterior = estado.jugadores[posTurnoAnterior].login;
                                        }
                                        estado.jugadores[pos].cartas.forEach(p=>{
                                            cartasJug.push(p);
                                        })
                                        
                                        response.status(200).json({historial,nombreGanador,estadoP,ultimas,jugadores,cartasJug, usu, nombrePartida,turno, cartasMesa, idPartida,restoCartas,vCartas,turnoAnterior})
                                    }
                                    }else{
                                        response.status(500);
                                        response.end();                               
                                    }
                                })
                            }else {response.status(500);
                                response.end();
                            }
                        } else{response.status(200).json({historial,jugadores, usu, idPartida,nombrePartida})}
                    }
                });
          
             } else {
                response.status(500);
                response.end();
             };
            });
        }else {response.status(500);
            response.end();
        }
    });
});

app.put("/jugar/:idPart",passport.authenticate('basic', {session: false}),(request, response)=>{
    let id = Number(request.params.idPart);
    let cartasSelec =[];
    let usu = request.user;
    cartasSelec= request.body.cartas;
    let valor = request.body.valor;
    daoPartida.getEstado(id, (error, rows)=>{
        if(!error){
            if(rows){
                let estado=JSON.parse(rows);
                estado.valorCartasMesa=valor;
                estado.cartasMesa.push(cartasSelec);
                estado.ultimasCartas=cartasSelec;
                let misCartas=[];
                let pos = obtenerJugador(usu, estado.jugadores);
                estado.jugadores[pos].cartas.forEach(p=>{
                    misCartas.push(p);
                });
                estado.jugadores[pos].cartas=eliminarCartas(cartasSelec, misCartas);
            
                estado.turno =(estado.turno + 1)%4;
                daoPartida.guardarEstado(estado,id,(err)=>{
                    if(!err){
                        daoPartida.getEstado(id,(error,rows)=>{
                            if(!error){
                                let estado1=JSON.parse(rows);
                            let numeros = estado1.ultimasCartas.length;
                            guardarHistorial("El jugador " + request.user + " ha puesto " + numeros  + " " + estado.valorCartasMesa, id, err=>{
                            response.status(200).json({});
                            });
                            }else{response.status(500);
                            response.end();}
                        });
                        
                       
                    }else{
                        response.status(500);
                        response.end();
                    }
                });
            }else{
                response.status(400);
                response.end();
            }
        }else{
            response.status(400);
            response.end();
        }
    });
    
});

app.put("/mentiroso/:idPart",passport.authenticate('basic', {session: false}),(request, response)=>{
    let id = Number(request.params.idPart);
    daoPartida.getEstado(id,(error, estado)=>{
        if(!error){
            if(estado){
                let estadoA=JSON.parse(estado);
                let posAnterior;
                    if(estadoA.turno === 0){
                        posAnterior = 3;
                    }else{
                        posAnterior = (estadoA.turno -1);
                    }
                    let booleano = comprobarMentiroso(estadoA.valorCartasMesa, estadoA.ultimasCartas);
                    let todasLasCartasMesa = cogerCartas(estadoA.cartasMesa);
                if(booleano){
                    todasLasCartasMesa.forEach(p=>{
                        estadoA.jugadores[posAnterior].cartas.push(p);
                    });
                    estadoA.turno = posAnterior;
                   
                }else{
                    todasLasCartasMesa.forEach(p=>{
                        estadoA.jugadores[estadoA.turno].cartas.push(p);
                    });
                }
                let guardarUltimas = estadoA.ultimasCartas; 
                estadoA.cartasMesa = [];
                estadoA.ultimasCartas = [];
                estadoA.valorCartasMesa = undefined;
                daoPartida.guardarEstado(estadoA, id,(error)=>{
                    if(!error){
                        let correcto;
                        if(booleano) correcto="acertado";
                        else correcto="fallado";

                        guardarHistorial("El jugador " + request.user + " ha dicho que el jugador anterior ha mentido y ha " + correcto, id, err=>{
                            response.status(200).json({guardarUltimas,booleano});
                        });
                        
                    }else {response.status(500);
                        response.end();
                    }
                });
            }else{
                response.status(400);
                response.end();
            }
        }else{
            response.status(400);
            response.end();
        }
    });
});

function comprobarMentiroso(valor,ultimasCartas){
    let mentiroso = false;
    let i = 0;
    while(i < ultimasCartas.length && !mentiroso){
        let carta = ultimasCartas[i].slice(0,1);
        if(valor !== carta){
            mentiroso = true;
        }
        i++;
    }
    return mentiroso;
}

function cogerCartas(cartasMesa){
    let total=[];
    let i = 0;
    cartasMesa.forEach(p=>{
        p.forEach(carta =>{
            total.push(carta);
        });
    });
    return total;
}

function contarCartas(cartasTotalMesa){
    let i = 0;
    cartasTotalMesa.forEach(p=>{
        i+=p.length;
    })
    return i;
}


function cartasRestoJugadores(estadoFinal){
    let i = 0;
    let array = [];
    while(i < estadoFinal.jugadores.length){

        array.push(estadoFinal.jugadores[i].cartas.length);

        i++;
    }
    return array;
}

function eliminarCartas(cartasSelec, misCartas){
    let encontrado = false;
    
    cartasSelec.forEach(p=>{
        let i = 0;
        encontrado = false;
        while(!encontrado){
            if(misCartas[i]===p){
                //eliminarcarta
                //desplazar
                misCartas = desplazar(misCartas, i);
                encontrado = true;
                i=0;
            }else{
                i++;
            }
            
        }
    });
    return misCartas;
}

function desplazar(misCartas, i){
    for(let j = i+1; j < misCartas.length; j++){
        misCartas[j-1] = misCartas[j];
    }
    misCartas.length--;
    return misCartas;
}

function obtenerJugador(nombre, jugadoresAleat){
    let i  = 0;
    while(i < jugadoresAleat.length){
        if(nombre === jugadoresAleat[i].login){
            return i;

        }
        else i++;
    }
}

function datosEstado(jugadores, cartasAleat){
    
    let jugadoresFinal=[];
    let j=0, i = 0;
    jugadores.forEach(p=>{
        let k=0;
        jugadoresFinal[i]={} 
        jugadoresFinal[i].login = (p.login);
        jugadoresFinal[i].cartas = [];
        while(k<(cartas.length/4)){ 
            jugadoresFinal[i].cartas.push(cartasAleat[j]);
            k++;
            j++;
        }
        i++;
    })
    let turno = jugadorAleat(jugadores);
    let estadoPartida = "activa";
    let cartasMesa = [];
    let valorCartasMesa=0;
    let estado={};
    let ultimasCartas=[];
    estado.jugadores=jugadoresFinal;
    estado.ultimasCartas=ultimasCartas;
    estado.turno=turno;
    estado.estadoPartida=estadoPartida;
    estado.cartasMesa=cartasMesa;
    estado.valorCartasMesa=valorCartasMesa;
    return estado;
}
//SOLO ES NECESARIO PARA LAS CARTAS
function aleatorio(lista){
    return  lista.sort(function() {return Math.random() - 0.5});    
}
  
function jugadorAleat(lista){
    return  Math.floor(Math.random()*(lista.length));
}

function guardarHistorial(evento, idPartida, callback) {
    daoPartida.crearHistorial(evento, idPartida, err=> {
        callback(err);
    });
}

app.listen(config.port, function(err){
    if(err){
        console.log("No se ha podido iniciar el servidor");
        console.log(err);
    }  else{
    console.log(`Servidor escuchando en puerto ${config.port}`);
    }

});
