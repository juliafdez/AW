
"use strict";
const express = require("express");
const app = express();
const path = require("path");
const config = require("./config");
const bodyParser = require("body-parser");
const mysql =require("mysql");
const daoUsers = require("./dao_users");
const daoAsks = require("./dao_ask");
const session = require("express-session");
const mysqlSession = require("express-mysql-session");

const mySQLStore = mysqlSession(session);
const sessionStore = new mySQLStore({
    host:config.mysqlconfig.dbHost,
    user:config.mysqlconfig.dbUser,
    password:config.mysqlconfig.dbPassword,
    database:config.mysqlconfig.dbName
});

const middlewareSession = session({
    saveUninitialized:false,
    secret:"agatajulia",
    resave:false,
    store: sessionStore
})

app.use(middlewareSession);

let pool = mysql.createPool({
    host:config.mysqlconfig.dbHost,
    user:config.mysqlconfig.dbUser,
    password:config.mysqlconfig.dbPassword,
    database:config.mysqlconfig.dbName
});

let daoUser = new daoUsers.DAOUsers(pool);
let daoAsk = new daoAsks.DAOAsk(pool);

const ficherosEstaticos =path.join(__dirname, "public");
app.use(express.static(ficherosEstaticos));
app.set("view engine" , "ejs");
app.set("views", path.join(__dirname, "views"));
app.use(bodyParser.urlencoded({ extended:false}));


/*Página de inicio */
app.get("/", (request,response)=>{
    response.redirect("/practica1.html");
});

/*Inicio sesion*/
app.post("/EntrarUsu.html", (request, response)=>{
    daoUser.isUserCorrect(request.body.correo, request.body.password, (error,exito)=>{
        if(error){ let mensajeError= error.message;
        response.render("Entrar", {mensajeError:mensajeError});
        }else{
            if(!exito){
                response.render("Entrar", {mensajeError:"Usuario y/o contraseña no validos"});
            }else{
                request.session.currentUser= request.body.correo;
                request.session.puntos = 0;
                response.redirect("/Perfil.html");
            }

        }
    });
});

/*Registrar nuevo usuario*/
app.post("/NuevoUsuReg.html", (request, response) => {
let usu={email: request.body.correo,
    password: request.body.password,
    nombre: request.body.nombre,
    sexo: request.body.sexo,
    fecha: request.body.fecha,
    imagen: request.body.imagen,
    puntos:0};

    daoUser.newUser(usu,(error, exito)=>{
    if(error){
        let mensajeError= error.message;
        response.render("NuevoUsu", {mensajeError:mensajeError});
    }else{
        if(!exito){
            response.render("NuevoUsu", {mensajeError:"Usuario ya existente"});
        }
        else{
            request.session.currentUser=request.body.correo;
            request.session.puntos = usu.puntos;//Almacena en la sesion el correo asociado al usuario
            response.redirect("/Perfil.html");
        }
    }
    });
});

app.get("/Entrar.html", (request, response) => {
    response.render("Entrar", {mensajeError:undefined});

});

app.get("/NuevoUsu.html", (request, response)=>{
    response.render("NuevoUsu", {mensajeError:undefined});
});



app.get("/imagenUsuario", (request, response)=>{
    daoUser.getUserImageName(request.session.currentUser, (error, imagen)=>{
        if(!error){
            if(!imagen){
                response.sendFile(path.join(__dirname,"noProfile.png"));
            }
            else{
                response.sendFile(path.join (__dirname, "/icons", imagen));
            }
        }
    });
});

app.get("/Perfil.html", (request,response)=>{
    daoUser.getAllDatas(request.session.currentUser, (error,datos)=>{
        request.session.puntos = datos.puntos;
        datos.fecha = Number(daoUser.edad(datos.fecha));
        if(!error){
            response.render("Perfil", {datos:datos, puntos:request.session.puntos, currentUser:request.session.currentUser});
        }
        else{
            console.log(error);
            response.end();
        }
    });
});

app.get("/Modificar.html", (request, response)=>{
            response.render("Modificar", {puntos:request.session.puntos});

});
/*Modificar usuario */
app.post("/ModificarUsu.html", (request,response)=>{
    let usuario={nombre:request.body.nombre, password:request.body.password, fecha:request.body.fecha,
    sexo:request.body.sexo, imagen:request.body.imagen,email:request.session.currentUser};
    daoUser.modificarUser(usuario,(error,datos)=>{
        if(!error){
                datos.fecha = Number(daoUser.edad(datos.fecha));
                    response.render("Perfil", {puntos: request.session.puntos, currentUser: request.session.currentUser, datos:datos});
        }
        else{
            console.log(error);
            response.end();
        }
    });

});

app.get("/Amigos.html", (request,response)=>{
     daoUser.getAllFriends(request.session.currentUser, (error,amigos)=>{
         if(!error){
             daoUser.getAllSolicitudes(request.session.currentUser, (error1, solicitudes)=>{
                 if(!error1){
                    response.render("Amigos", {puntos:request.session.puntos,solicitudes:solicitudes, amigos:amigos});
                 }
             })
             
        }
        else{
             console.log(error);
             response.end();
            }
        })
});

/*Buscar usuarios */
app.get("/Busqueda.html", (request,response)=>{

    daoUser.buscarUser(request.query.buscar, request.session.currentUser,(error,datos)=>{
        if(!error){
            if(datos){
                response.render("Buscar", {nombre:request.query.buscar, mensajeError:undefined, datos:datos, puntos: request.session.puntos});
            }
            else{
                response.render("Buscar", {nombre:request.query.buscar, mensajeError:"No se ha encontrado ningun usuario", datos:datos, puntos: request.session.puntos});
            }
        }
        else{
            console.log(error);
            response.end();//¿?
        }
    });
});

app.get("/Solicitar.html", (request, response)=>{
    daoUser.insertarSolicitud(request.session.currentUser, request.query.emailAmigo, (error)=>{
        if(error){callback(error); return;}
        else{
            response.redirect("/Amigos.html");
        }
    });
});

app.post("/AceptarRechazar.html", (request, response)=>{
    if(request.body.valor2){
        daoUser.rechazarSolicitud(request.session.currentUser, request.body.rech, (error)=>{
            if(error){callback(error); return;}
            else{response.redirect("/Amigos.html");
        }
        })
    }else if(request.body.valor1){
        daoUser.aceptarSolicitud(request.session.currentUser, request.body.acept, (error)=>{
            if(error){callback(error); return;}
            else{response.redirect("/Amigos.html");
        }
        });
    }
});

app.get("/PerfilAmigo.html", (request, response)=>{
    daoUser.getAllDatas(request.query.email, (error,datos)=>{
        if(!error){
            if(datos){
                datos.fecha = Number(daoUser.edad(datos.fecha)); 
                response.render("Perfil", {datos:datos, puntos:request.session.puntos, currentUser:request.session.currentUser});
            }
        }
        else{
            response.render("Perfil",{datos:datos, puntos:request.session.puntos, currentUser:request.session.currentUser});
        }
    });
});

app.get("/Preguntas.html", (request, response)=>{
    daoAsk.getPreguntasAleatorias((preguntas)=>{
        response.render("Preguntas",{preguntas:preguntas, puntos:request.session.puntos});
    });
});


app.post("/Anadir.html", (request, response)=>{
    let numOp=[];
    numOp = request.body.areaOpciones.split("\n").filter(elem => elem.length > 0 && elem.trim());
    daoAsk.addNewAsk(request.body.pregunta,  numOp, (error, preguntas)=>{
        if(!error){
            if(preguntas){
                response.redirect("/Preguntas.html");
            }else{
                response.redirect("/Preguntas.html");
            }
        }else{
            console.log(error);
            response.end();
        }
    });
});


app.get("/PaginaPreguntas.html", (request, response)=>{
    response.redirect("/preguntasNuevas.html");
});

app.get("/preguntasNuevas.html",(request, response)=>{
    response.render("preguntasNuevas",{puntos:request.session.puntos});

});

app.get("/ResponderPregunta.html",(request, response)=>{
    let id = request.query.id;
    daoAsk.getDatosPregunta(id,(error, datos)=>{
        if(!error){
            if(datos){
               daoAsk.preguntaRespondida(request.session.currentUser, id, (err, exito)=>{
                   if(!err){
                            daoAsk.getPreguntasRespondidasdeAmigos(request.session.currentUser, id, (error2, amigosRespuesta)=>{
                                if(!error2){
                                        response.render("ContestarAdivinar", {respondida:exito,preguntas:datos,puntos:request.session.puntos, amigosR:amigosRespuesta});
                                       
                                }
                            });                   
                        }
                        else{
                            response.redirect("/Preguntas.html");}
               });
                
            }
            else{
                response.redirect("/Preguntas.html");}
        }
        else{
        response.redirect("/Preguntas.html");}
    });
    
});

app.get("/ContestarAdivinar.html",(request, response)=>{

    response.render("ContestarAdivinar",{puntos:request.session.puntos, preguntas:undefined});
});

app.get("/Contestar.html", (request, response)=>{
    let id= request.query.idP;
    daoAsk.getDatosPregunta(id, (error, datos)=>{
        if(!error){
            if(datos){
            daoAsk.getOpciones(id, (error, opciones)=>{
                response.render("Responder", {datos:datos, opciones:opciones, puntos:request.session.puntos});
            });
        }
        }else{
            response.redirect("/Preguntas.html");
        }
    });

});

app.post("/Responder.html", (request, response)=>{
    let id_op=request.body.opcion;
    if(request.body.otra){
        daoAsk.addRespuesta(request.body.idP, request.body.otra, request.session.currentUser, (error)=>{
            if(!error){
                response.redirect("/Preguntas.html");
            }
        });
    }
    else{
        daoAsk.addNewAnswer(id_op,request.session.currentUser,(error)=>{
            if(!error){
                response.redirect("/Preguntas.html");
            }
            else{
                response.redirect("/Preguntas");
            }
        })
    }
});

app.get("/AdivinarAmigo.html", (request, response)=>{
    let emailA = request.query.emailA;
    let id= request.query.idP;
    daoUser.getAllDatas(emailA, (err, datas)=>{
        if(!err){
            if(datas){
                daoAsk.getOpcionesAmigo(emailA, id, (error, opcionesA)=>{
                    if(!error){
                        if(opcionesA){
                        daoAsk.getDatosPregunta(id, (error, datos)=>{
                            if(datos){
                                response.render("ResponderAmigo",{opcionesA: opcionesA, datos:datos, puntos:request.session.puntos, amigos:datas});
                            }
                        })
                        
                            
                        }
                    }
                })
            }
        }
    })
   
});

app.post("/ResponderAmigo.html", (request, response)=>{
    let opcion = request.body.opcion;
    let idP = request.body.idP;
    let amigo = request.body.amigo;
    daoAsk.insertarRespuestaAmigo(request.session.currentUser, amigo, idP, opcion, (error)=>{
        if(!error){
            response.redirect("/Preguntas.html"); 
        }else{
            response.redirect("/Preguntas.html");
        }
    })
});

app.get("/Desconectar.html", (request,response)=>{
    request.session.destroy();
    response.redirect("/Entrar.html");
});

app.listen(config.port, function(err){
    if(err){
        console.log("No se ha podido iniciar el servidor")
        console.log(err);
    }
    else{
        console.log(`Servidor escuchando en puerto ${config.port}`);
    }
});