module.exports={
    mysqlconfig: {
        dbName: "usuarios",
        dbHost: "localhost",
        dbUser: "root",
        dbPassword: "",
    },
    port:3000
};