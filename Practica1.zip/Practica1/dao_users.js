"use strict";


/**
 * Proporciona operaciones para la gestión de usuarios
 * en la base de datos.
 */
class DAOUsers {
    /**
     * Inicializa el DAO de usuarios.
     * 
     * @param {Pool} pool Pool de conexiones MySQL. Todas las operaciones
     *                    sobre la BD se realizarán sobre este pool.
     */
    constructor(pool) {
        this.pool = pool;
    }

    /**
     * Determina si un determinado usuario aparece en la BD con la contraseña
     * pasada como parámetro.
     * 
     * Es una operación asíncrona, de modo que se llamará a la función callback
     * pasando, por un lado, el objeto Error (si se produce, o null en caso contrario)
     * y, por otro lado, un booleano indicando el resultado de la operación
     * (true => el usuario existe, false => el usuario no existe o la contraseña es incorrecta)
     * En caso de error error, el segundo parámetro de la función callback será indefinido.
     * 
     * @param {string} email Identificador del usuario a buscar
     * @param {string} password Contraseña a comprobar
     * @param {function} callback Función que recibirá el objeto error y el resultado
     */
    isUserCorrect(email, password, callback) {
        this.pool.getConnection((err, connection) => {
            if(err){
                callback(err);
            }
            else{
            connection.query("SELECT email, password FROM usuarios WHERE email = ? and password = ?",
            [email, password],
            (err, rows) => {
            if (err) { callback(err); }
          //  connection.release();
            if (rows.length === 0) {
                callback(null, false);
            } else {
                callback(null, true);
            }
            });
        }
        connection.release();
        });
        
    }

    newUser(user,callback){
        this.pool.getConnection((err,connection)=>{
            if(err){
                callback(err);
            }
            else{
                connection.query("SELECT email FROM usuarios WHERE email = ?", 
                [user.email], 
                (error,rows)=>{
                    if (error) { callback(error); }
                        //connection.release();
                   if (rows.length === 0) {
                        connection.query("INSERT INTO usuarios VALUES (?,?,?,?,?,?, ?)", [user.nombre, user.email,
                            user.password, user.sexo, user.fecha, user.imagen, user.puntos],
                        (err)=>{
                            if(err){ callback(err);}
                            else{callback(null);}
                        });
                        callback(null, true);
                    } else {
                        callback(null,false);
                    }
                });
               
            }
            connection.release();
        });
    }

    edad(fecha){
        let fecha_nacimiento= new Date(fecha);
        let i = new Date();
        let anios = i.getFullYear() - fecha_nacimiento.getFullYear();
        let mes = i.getMonth() - fecha_nacimiento.getMonth();
        if(mes < 0 || (mes === 0 && i.getDate() < fecha_nacimiento.getDate())){
            anios--;
        }
        return anios;
    }

    /**
     * Obtiene el nombre de fichero que contiene la imagen de perfil de un usuario.
     * 
     * Es una operación asíncrona, de modo que se llamará a la función callback
     * pasando, por un lado, el objeto Error (si se produce, o null en caso contrario)
     * y, por otro lado, una cadena con el nombre de la imagen de perfil (o undefined
     * en caso de producirse un error).
     * 
     * @param {string} email Identificador del usuario cuya imagen se quiere obtener
     * @param {function} callback Función que recibirá el objeto error y el resultado
     */
    getUserImageName(email, callback) {
        this.pool.getConnection((err, connection) => {
            if (err) { callback(err); return; }
            connection.query("SELECT img FROM usuarios WHERE email = ?",
            [email],
            (err, rows) => {
                if (err) { callback(err); return; }
                //connection.release();
                if (rows.length === 0) {
                    callback(null, undefined);
                } else {
                    callback(null, rows[0].imagen);
                }
            });
            connection.release();
        });
    }   

    getAllDatas(email,callback){
        this.pool.getConnection((err, connection) => {
            if (err) { callback(err); return; }
           else{ connection.query("SELECT nombre, email, password, sexo, fecha,  puntos FROM usuarios WHERE email = ?",
            [email],
            (error,rows) => {
                if(error){
                    callback("Error", undefined);
                }
                else{
                    if(rows.length!==0){
                        let datos={/*falta la imagen*/email:rows[0].email, password: rows[0].password,
                            nombre:rows[0].nombre, fecha:rows[0].fecha, sexo:rows[0].sexo,
                            puntos: rows[0].puntos};
                            callback(null, datos);
                    }
                    else{
                        callback("Usuario no encontrado", undefined);   
                    }
                }
                });
            }
            connection.release();
        });
    }


    modificarUser(usuario,callback){
        this.pool.getConnection((err, connection)=>{
            if (err) { callback(err); return; }
            else{ connection.query("UPDATE usuarios SET nombre = ?,  password = ?, sexo = ?, fecha = ?, img = ? WHERE  email = ?",
             [usuario.nombre,usuario.password, usuario.sexo, usuario.fecha, usuario.imagen, usuario.email],
             (error,rows) => {
                 if(error){
                    callback("Error al modificar", undefined);
                 }
                 else{
                     
                     callback(null,usuario);
                    }
                });

            }
            connection.release();
        });
    
    }

    buscarUser(buscar, email,callback){
        this.pool.getConnection((err, connection)=>{
            if (err) { callback(err); return; }
            else{ connection.query("SELECT nombre, email FROM usuarios WHERE nombre LIKE ?  AND email != ? AND email NOT IN (SELECT amigo FROM amigos WHERE usuario = ?) AND email NOT IN (SELECT usuario FROM amigos WHERE amigo =?)",
             ["%"+ buscar + "%", email, email, email],
             (error,rows) => {
                 if(error){
                    callback("Error al buscar", undefined);
                 }
                 else if(rows.length>0){
                     let usuarios=[];
                     rows.forEach(p=>{
                         usuarios.push({nombre:p.nombre, email:p.email});
                     })
                     callback(null,usuarios);
                }
                else{
                    callback(error,undefined);
                }

                });

            }
            connection.release();
        });
    }
    getAllFriends(email,callback){
        this.pool.getConnection((err, connection) => {
            if (err) { callback(err); return; }
           else{ connection.query("SELECT nombre, email FROM amigos JOIN usuarios ON amigo=usuarios.email WHERE usuario = ? AND a_pendiente != 1",
            [email],
            (error,rows) => {
                if(error){
                    callback(error, undefined);
                }
                else if(rows.length>0){
                    let amigos=[];
                    rows.forEach(p=>{
                        amigos.push({nombre:p.nombre, email:p.email});
                    })
                    callback(null,amigos);
               }
               else{
                   callback(error,undefined);
                }
                });
            }
            connection.release();
        });
    }

    getAllSolicitudes(email, callback){
        this.pool.getConnection((err, connection)=>{
            if (err) { callback(err); return; }
            else{
                connection.query("SELECT usuarios.nombre, usuarios.email FROM amigos, usuarios WHERE amigos.amigo = usuarios.email and amigos.usuario=? and a_pendiente=1", [email], 
            (error, rows)=>{
                if(error){
                    callback(error, undefined);
                }else {
                if(rows.length > 0){
                    let solicitudes=[];
                    rows.forEach(p=>{
                        solicitudes.push({nombre:p.nombre, email:p.email});
                    })
                    callback(null,solicitudes);
                }else{
                    callback(null, undefined);
                }
            }
            });
            }
            connection.release();
        });
    }

    insertarSolicitud(email, amigo, callback){
        this.pool.getConnection((err, connection)=>{
            if (err) { callback(err); return; }
            else{
                connection.query("INSERT INTO amigos VALUES (?, ?, 1)", [amigo, email], 
            (error)=>{
                if(error){
                    callback(error);
                }else{
                    callback(null);
                }
            });
            }
            connection.release();
        });
    }

    rechazarSolicitud(email, amigo, callback){
        this.pool.getConnection((err, connection)=>{
            if (err) { callback(err); return; }
            else{
                connection.query("DELETE FROM amigos WHERE usuario=? AND amigo = ?", [email, amigo], 
            (error)=>{
                if(error){
                    callback(error);
                }else{
                    callback(null);
                }
            });
            }
            connection.release();
        });
    }

    aceptarSolicitud(email, amigo, callback){
        this.pool.getConnection((err, connection)=>{
            if (err) { callback(err); return; }
            else{
                connection.query("UPDATE  amigos SET a_pendiente=0 WHERE usuario=? AND amigo = ?", [email, amigo], 
            (error)=>{
                if(error){
                    callback(error);
                }else{
                    connection.query("INSERT INTO amigos VALUES(?,?,0)", [amigo,email], (error2)=>{
                        if(error2){
                            callback(error2);
                        }
                    });
                    callback(null);
                }
            });
            }
            connection.release();
       });

    }

}

module.exports = {
    DAOUsers: DAOUsers
}