"use strict";


/**
 * Proporciona operaciones para la gestión de usuarios
 * en la base de datos.
 */
class DAOAsk {
    /**
     * Inicializa el DAO de usuarios.
     * 
     * @param {Pool} pool Pool de conexiones MySQL. Todas las operaciones
     *                    sobre la BD se realizarán sobre este pool.
     */
    constructor(pool) {
        this.pool = pool;
    }

   addNewAsk(texto, respuestas, callback){
    this.pool.getConnection((err, connection)=>{
        if (err) { callback(err); return; }
        else{
            connection.query("INSERT INTO preguntas(texto_pregunta, opcion) VALUES (?,?)", [texto, respuestas.length], 
        (error)=>{
            if(error){
                callback(error);
            }else{
                connection.query("SELECT id_pregunta FROM preguntas WHERE texto_pregunta = ?", [texto], (error2, rows)=>{
                    if(!error2){
                        respuestas.forEach(p=>{
                            connection.query("INSERT INTO opciones(id_pregunta, opcion) VALUES (?, ?)",[rows[0].id_pregunta, p], (error3)=>{
                                if(error3){callback(error3);}
                            });
                        });
                        callback(null,respuestas);
                        }else{
                            callback(error2, null);
                        }
                });
            }
        });
        }
        connection.release();
    });
   }

   addRespuesta(id, texto, email, callback){
    this.pool.getConnection((err, connection)=>{
        if (err) { callback(err); return; }
        else{
            connection.query("INSERT INTO opciones(id_pregunta, opcion) VALUES (?, ?)", [id,texto], (error)=>{
                if(!error){
                    connection.query("SELECT id_opcion FROM opciones WHERE id_pregunta=? AND opcion = ?",[id, texto],(error1,rows)=>{
                        if(!error1){
                            if(rows.length > 0){
                                connection.query("INSERT INTO respuestas VALUES (?,?,?)",[email, id, rows[0].id_opcion], (error2)=>{
                                    if(error2){
                                        callback(error2);
                                    }else{
                                        callback(null);
                                    }
                                });
                            }
                        }
                        else{
                            callback(error1,undefined);
                        }
                    })
                }
                else{
                    callback(error);
                }
            });
        }
        connection.release();
    });
   }

   getPreguntasAleatorias(callback){
    this.pool.getConnection((err, connection)=>{
        if (err) { callback(err); return; }
        else{
            connection.query("SELECT texto_pregunta, id_pregunta FROM preguntas ORDER BY rand() LIMIT 5", (error, rows)=>{
                if(error){callback(error); return;}
                else{
                    if(rows.length>0){
                        let preguntas=[];
                        rows.forEach(p=>{
                            preguntas.push({pregunta:p.texto_pregunta, id:p.id_pregunta});
                        });
                        callback(preguntas);
                    }else{ callback(null);}
                    }
                });
            }
            connection.release();
        });
    }

    responderPregunta(idPregunta, email, idOpcion, callback){
        this.pool.getConnection((err, connection)=>{
            if (err) { callback(err); return; }
            else{
                connection.query("INSERT INTO respuestas VALUES (?,?,?)",[email,idPregunta,idOpcion],(error)=>{
                    if(!error){
                        callback(null);
                    }else{callback(error);}
                });
            }
            connection.release();
        });
    }

    getOpciones(idPregunta, callback){
        this.pool.getConnection((err, connection)=>{
            if (err) { callback(err); return; }
            else{
                connection.query("SELECT opciones.id_opcion, opciones.opcion, opciones.id_pregunta FROM opciones, preguntas WHERE opciones.id_pregunta=preguntas.id_pregunta AND opciones.id_pregunta=?",[idPregunta],(error, rows)=>{
                    if(!error){
                        let opciones = [];
                        rows.forEach(p=>{
                            opciones.push({opcion:p.opcion, id_opcion:p.id_opcion, id_pregunta:p.id_pregunta});
                        });
                        callback(null, opciones);
                    }else{callback(error, undefined);}
                });
            }
            connection.release();
        });

    }

    getDatosPregunta(texto, callback){
        this.pool.getConnection((err, connection)=>{
            if (err) { callback(err); return; }
            else{
                connection.query("SELECT * FROM preguntas WHERE id_pregunta = ?",[texto],(error, rows)=>{
                    if(!error){
                        if(rows.length>0){
                            let datos={
                                idPregunta:rows[0].id_pregunta, 
                                texto:rows[0].texto_pregunta, 
                                opciones:rows[0].opcion};
                            callback(null, datos);
                        }else{
                            callback(null, undefined);
                        }
                    }
                });
            }
            connection.release();
        });
    }

    addNewAnswer(id, email, callback){
        this.pool.getConnection((err, connection)=>{
            if(err){callback(err); return;}
            else{
                connection.query("SELECT id_pregunta FROM opciones WHERE id_opcion =?",[id],(error1, rows)=>{
                    if(!error1){
                        if(rows.length>0){
                            connection.query("INSERT INTO respuestas VALUES (?,?,?)",[email, rows[0].id_pregunta, id],(error)=>{
                                if(!error){
                                    callback(null);
                                }else{callback(error);}
                            });
                        }
                    }else{callback(error1,undefined);}
                });
            }
            connection.release();
        });
    }

    preguntaRespondida(email, idP, callback){
        this.pool.getConnection((err, connection)=>{
            if(err){callback(err); return;}
            else{
                connection.query("SELECT emailUsu, id_pregunta FROM respuestas WHERE emailUsu = ? AND id_pregunta=?",[email, idP],(error, rows)=>{
                    if(!error){
                        if(rows.length>0){
                            callback(null, true);
                        }else{
                            callback(null, false);
                        }
                    }else{
                        callback(error, false);
                    }
                });
            }
            connection.release();
        });
    }

    getPreguntasRespondidasdeAmigos(email, idP, callback){
        this.pool.getConnection((err, connection)=>{
            if(err){callback(err); return ;}
            else{
                connection.query("SELECT usuarios.email, usuarios.nombre, respuestas.id_opcion FROM respuestas, amigos, usuarios WHERE amigos.usuario = ? and amigos.amigo=respuestas.emailUsu and amigos.amigo= usuarios.email and respuestas.id_pregunta=? and a_pendiente = 0 ORDER BY usuarios.email", 
                [email, idP], (error, rows)=>{
                    if(!error){
                        connection.query("SELECT emailAmigo, acertada FROM respuestasAmigos WHERE emailUsuario = ? AND id_pregunta = ? ORDER BY emailAmigo", [email, idP], (error2, filas)=>{

                            if(!error2){
                                let preguntasContestadas = [];
                                let tam = 0;
                            
                                for(let i = 0; i < rows.length; i++){
                                    if(tam < filas.length && rows[i].email && filas[tam].emailAmigo){ 
                                        preguntasContestadas.push({nombre:rows[i].nombre, email:rows[i].email, acertada: filas[tam].acertada});
                                        tam++;
                                    }else{
                                        preguntasContestadas.push({nombre:rows[i].nombre, email:rows[i].email, acertada: -1});
                                    }
                                }
                                callback(null, preguntasContestadas);
                            }else{callback(error2, undefined);}
                        }); 
                        
                }else{
                    callback(error, undefined);
                }
                });
                
            }
            connection.release();
        });
    }

    acertadaDeAmigo(email, emailAmigo, callback){
        this.pool.getConnection((error, connection)=>{
            if(error){callback(error); return;}
            else{
                connection.query("SELECT acertada FROM respuestasAmigos, respuestas WHERE emailUsuario = ? and respuestasAmigos.emailAmigo = ? and respuestasAmigos.emailAmigo = respuestas.emailUsu ")
            }
        })
    }

   
    getOpcionesAmigo(emailAmigo, idP, callback){
        this.pool.getConnection((err,connection)=>{
            if(err){callback(err); return;}
            else{
                connection.query("SELECT id_opcion, opcion FROM respuestas NATURAL JOIN opciones WHERE emailUsu = ? AND id_pregunta = ?",[emailAmigo, idP], (error, rows)=>{
                    if(!error){
                        if(rows.length>0){
                            connection.query("SELECT opcion FROM preguntas WHERE id_pregunta = ?", [idP], (errorr, op)=>{
                                if(!errorr){
                                    if(op){
                                        connection.query("SELECT opciones.id_opcion, opciones.opcion FROM opciones , preguntas WHERE opciones.id_pregunta = preguntas.id_pregunta AND preguntas.id_pregunta = ? AND id_opcion != ? ORDER BY rand() LIMIT ? ",[idP, rows[0].id_opcion,(op[0].opcion -1)], (error2, filas)=>{
                                            if(!error2){
                                                if(filas.length>0){
                                                    let opciones = [];
                                                    let _ = require("underscore");
                                                    opciones[0] = ({id_opcion:rows[0].id_opcion, opcion:rows[0].opcion});
                                                    
                                                    for(let i = 0; i < filas.length;i++){
                                                        opciones[i+1] = ({id_opcion:filas[i].id_opcion, opcion:filas[i].opcion});
                                                    }
                                                    _.shuffle(opciones);
                                                    callback(null, opciones);
                                                }
                                            }else{callback(error2, undefined);}
                                        });
                                    }
                                }
                            })
                        }
                    }else{callback(error, undefined);}
                });
            }
            connection.release();
        });
    }

    insertarRespuestaAmigo(email, emailAmigo, idP, idO, callback){
        this.pool.getConnection((err, connection)=>{
            if(err){callback(err); return;}
            else{
                connection.query("SELECT id_opcion FROM respuestas WHERE emailUsu = ? AND id_pregunta = ?",[emailAmigo, idP], (error, rows)=>{
                    if(!error){
                        if(rows.length>0){
                            if(rows[0].id_opcion == idO){

                                connection.query("INSERT INTO respuestasAmigos VALUES (?,?,?,?,1)",[email, emailAmigo, idO, idP], (error1)=>{
                                    if(!error1){
                                        connection.query("UPDATE usuarios SET puntos = puntos + 50 WHERE email=?",[email], (error3)=>{
                                            if(!error3){
                                                callback(null);
                                            }
                                        });
                                        
                                    }else{
                                        callback(error1);
                                    }
                                })
                            }else{
                                connection.query("INSERT INTO respuestasAmigos VALUES (?,?,?,?,2)",[email, emailAmigo, idO, idP],(error2)=>{
                                    if(!error2){
                                        callback(null);
                                    }
                                    else{
                                        callback(error2);
                                    }
                                });
                            }
                        }
                    }else{callback(error);}
                });
            }
            connection.release();
        });
    }

}

module.exports = {
    DAOAsk: DAOAsk
}