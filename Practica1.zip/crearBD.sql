-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 17-12-2017 a las 22:56:30
-- Versión del servidor: 10.1.28-MariaDB
-- Versión de PHP: 7.1.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `usuarios`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `amigos`
--

CREATE TABLE `amigos` (
  `usuario` varchar(50) NOT NULL DEFAULT '',
  `amigo` varchar(50) NOT NULL DEFAULT '',
  `a_pendiente` int(8) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `amigos`
--

INSERT INTO `amigos` (`usuario`, `amigo`, `a_pendiente`) VALUES
('agatasan@ucm.es', 'alberto@ucm.es', 0),
('agatasan@ucm.es', 'gonzalo@ucm.es', 0),
('agatasan@ucm.es', 'nacho@ucm.es', 0),
('alberto@ucm.es', 'agatasan@ucm.es', 0),
('alberto@ucm.es', 'gonzalo@ucm.es', 0),
('gonzalo@ucm.es', 'agatasan@ucm.es', 0),
('gonzalo@ucm.es', 'alberto@ucm.es', 0),
('gonzalo@ucm.es', 'nacho@ucm.es', 0),
('nacho@ucm.es', 'alberto@ucm.es', 1),
('nacho@ucm.es', 'gonzalo@ucm.es', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `opciones`
--

CREATE TABLE `opciones` (
  `id_opcion` int(10) NOT NULL,
  `id_pregunta` int(10) NOT NULL,
  `opcion` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `opciones`
--

INSERT INTO `opciones` (`id_opcion`, `id_pregunta`, `opcion`) VALUES
(65, 42, 'Nintendo Switch\r'),
(66, 42, 'PS4\r'),
(67, 42, 'Xbox One\r'),
(68, 42, 'No me gustan esas cosas'),
(69, 43, 'Maria\r'),
(70, 43, 'Manuela\r'),
(71, 43, 'Ines\r'),
(72, 43, 'Susana'),
(73, 44, 'Tom\r'),
(74, 44, 'Jerry\r'),
(75, 44, 'Spike\r'),
(76, 44, 'Sam'),
(77, 45, '1\r'),
(78, 45, '2\r'),
(79, 45, '3\r'),
(80, 45, '4'),
(81, 46, 'Tocar el piano\r'),
(82, 46, 'Leer\r'),
(83, 46, 'Bailar\r'),
(84, 46, 'Patinar'),
(85, 47, 'Me encanta\r'),
(86, 47, 'No mucho\r'),
(87, 47, 'Lo odio\r'),
(88, 47, 'Solo el chocolate blanco'),
(89, 48, 'Carbonara\r'),
(90, 48, 'Boloñesa\r'),
(91, 48, 'No me gusta la pasta'),
(92, 49, 'Reggaeton\r'),
(93, 49, 'Pop\r'),
(94, 49, 'Rock\r'),
(95, 49, 'Rap\r'),
(96, 49, 'Clasica'),
(97, 48, 'Con queso'),
(98, 46, 'Morirme'),
(99, 44, 'Lula'),
(100, 45, '5'),
(101, 50, 'Azules\r'),
(102, 50, 'Verdes\r'),
(103, 50, 'Marrones');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `preguntas`
--

CREATE TABLE `preguntas` (
  `id_pregunta` int(10) NOT NULL,
  `texto_pregunta` text NOT NULL,
  `opcion` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `preguntas`
--

INSERT INTO `preguntas` (`id_pregunta`, `texto_pregunta`, `opcion`) VALUES
(42, '¿Nintento Switch, PS4, o Xbox One?', 4),
(43, '¿Como  se llama mi madre?', 4),
(44, '¿Como se llama mi perro?', 4),
(45, '¿Cuantos hermanos tengo?', 4),
(46, '¿Cual es mi hobbie?', 4),
(47, '¿Me gusta el dulce?', 4),
(48, '¿Como me gusta la pasta?', 3),
(49, '¿Que tipo de musica me gusta?', 5),
(50, '¿De que color son mis ojos?', 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `respuestas`
--

CREATE TABLE `respuestas` (
  `emailUsu` varchar(50) NOT NULL,
  `id_pregunta` int(10) NOT NULL,
  `id_opcion` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `respuestas`
--

INSERT INTO `respuestas` (`emailUsu`, `id_pregunta`, `id_opcion`) VALUES
('agatasan@ucm.es', 42, 66),
('agatasan@ucm.es', 43, 71),
('agatasan@ucm.es', 46, 98),
('agatasan@ucm.es', 44, 99),
('agatasan@ucm.es', 45, 100),
('alberto@ucm.es', 48, 97),
('gonzalo@ucm.es', 42, 66),
('gonzalo@ucm.es', 45, 79);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `respuestasamigos`
--

CREATE TABLE `respuestasamigos` (
  `emailUsuario` varchar(50) NOT NULL,
  `emailAmigo` varchar(50) NOT NULL,
  `id_respuesta` int(50) NOT NULL,
  `id_pregunta` int(10) NOT NULL,
  `acertada` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `respuestasamigos`
--

INSERT INTO `respuestasamigos` (`emailUsuario`, `emailAmigo`, `id_respuesta`, `id_pregunta`, `acertada`) VALUES
('alberto@ucm.es', 'agatasan@ucm.es', 74, 44, 2),
('alberto@ucm.es', 'agatasan@ucm.es', 79, 45, 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sessions`
--

CREATE TABLE `sessions` (
  `session_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `expires` int(11) UNSIGNED NOT NULL,
  `data` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `sessions`
--

INSERT INTO `sessions` (`session_id`, `expires`, `data`) VALUES
('n2t0-4vpwdxWfizCFc_mKhBNtml2XijP', 1513634163, '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"httpOnly\":true,\"path\":\"/\"},\"currentUser\":\"alberto@ucm.es\",\"puntos\":150}');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `nombre` varchar(50) NOT NULL,
  `email` varchar(70) NOT NULL,
  `password` varchar(20) NOT NULL,
  `sexo` char(1) NOT NULL,
  `fecha` varchar(10) DEFAULT NULL,
  `img` varchar(30) DEFAULT NULL,
  `puntos` int(10) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`nombre`, `email`, `password`, `sexo`, `fecha`, `img`, `puntos`) VALUES
('Agata Sanchez Andreu', 'agatasan@ucm.es', 'agata', 'm', '1996-08-18', '', 100),
('Alberto Camino', 'alberto@ucm.es', 'alberto', 'h', '1996-04-19', '', 150),
('Gonzalo Navarro', 'gonzalo@ucm.es', 'gonzalo', 'h', '1995-05-21', '', 100),
('Julia Fernandez', 'julferna@ucm.es', 'julia', 'm', '1995-09-15', '', 100),
('Ignacio Domingo', 'nacho@ucm.es', 'nacho', 'h', '1996-02-15', '', 100),
('Pepe Ramos Gomez', 'pepe@ucm.es', 'pepe', 'o', '0064-07-31', '', 0);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `amigos`
--
ALTER TABLE `amigos`
  ADD PRIMARY KEY (`usuario`,`amigo`),
  ADD KEY `amigo` (`amigo`);

--
-- Indices de la tabla `opciones`
--
ALTER TABLE `opciones`
  ADD PRIMARY KEY (`id_opcion`);

--
-- Indices de la tabla `preguntas`
--
ALTER TABLE `preguntas`
  ADD PRIMARY KEY (`id_pregunta`);

--
-- Indices de la tabla `respuestas`
--
ALTER TABLE `respuestas`
  ADD PRIMARY KEY (`emailUsu`,`id_opcion`),
  ADD KEY `id_opcion` (`id_opcion`);

--
-- Indices de la tabla `respuestasamigos`
--
ALTER TABLE `respuestasamigos`
  ADD PRIMARY KEY (`emailUsuario`,`emailAmigo`,`id_respuesta`,`id_pregunta`),
  ADD KEY `emailAmigo` (`emailAmigo`),
  ADD KEY `id_respuesta` (`id_respuesta`),
  ADD KEY `id_pregunta` (`id_pregunta`);

--
-- Indices de la tabla `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`session_id`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`email`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `opciones`
--
ALTER TABLE `opciones`
  MODIFY `id_opcion` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=104;

--
-- AUTO_INCREMENT de la tabla `preguntas`
--
ALTER TABLE `preguntas`
  MODIFY `id_pregunta` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `amigos`
--
ALTER TABLE `amigos`
  ADD CONSTRAINT `amigos_ibfk_1` FOREIGN KEY (`usuario`) REFERENCES `usuarios` (`email`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `amigos_ibfk_2` FOREIGN KEY (`amigo`) REFERENCES `usuarios` (`email`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `respuestas`
--
ALTER TABLE `respuestas`
  ADD CONSTRAINT `respuestas_ibfk_1` FOREIGN KEY (`emailUsu`) REFERENCES `usuarios` (`email`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `respuestas_ibfk_2` FOREIGN KEY (`id_opcion`) REFERENCES `opciones` (`id_opcion`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `respuestasamigos`
--
ALTER TABLE `respuestasamigos`
  ADD CONSTRAINT `respuestasamigos_ibfk_1` FOREIGN KEY (`emailAmigo`) REFERENCES `usuarios` (`email`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `respuestasamigos_ibfk_2` FOREIGN KEY (`id_respuesta`) REFERENCES `opciones` (`id_opcion`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `respuestasamigos_ibfk_3` FOREIGN KEY (`id_pregunta`) REFERENCES `preguntas` (`id_pregunta`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
